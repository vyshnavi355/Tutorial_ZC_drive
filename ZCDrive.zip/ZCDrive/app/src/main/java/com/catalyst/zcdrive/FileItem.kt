package com.catalyst.zcdrive
data class FileItem(
    val file_name: String,
    val file_id: Long,
    val created_time:String,
    val row_id:Long,
    val file_type:String
)

